import pickle
from django.shortcuts import render
from .forms import PredictionForm

def predict(request):
    if request.method == 'POST':
        form = PredictionForm(request.POST)
        if form.is_valid():
            # Load the saved model
            model = pickle.load(open('finalized_model.sav', 'rb'))

            # Get the form data
            product = form.cleaned_data['product']
            quantity = form.cleaned_data['quantity']
            price = form.cleaned_data['price']
            month = form.cleaned_data['month']
            city = form.cleaned_data['city']
            hour = form.cleaned_data['hour']

            # Make the prediction
            prediction = model.predict([[product, quantity, price, month, city, hour]])

            # Render the result template
            return render(request, 'result.html', {'prediction': prediction})

    else:
        form = PredictionForm()

    return render(request, 'index.html', {'form': form})
